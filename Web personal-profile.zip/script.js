function contactMe() {
    const contactOptions = `
        <h3>Contact Me</h3>
        <p>Choose a method:</p>
        <button onclick="window.open('https://wa.me/your-number', '_blank')">WhatsApp</button>
        <button onclick="window.open('https://t.me/your-username', '_blank')">Telegram</button>
    `;
    alert(contactOptions);
}


